﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace cmpg223_final_project
{
    public partial class Stock : Form
    {
        public Stock()
        {
            InitializeComponent();
        }

        DbConnection db = new DbConnection();

        private void ShowAll()
        {
            try
            {
                string query = "SELECT * FROM `paris_pub`.stock";
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, db.Connection);
                using (db.Connection)
                {
                    using (adapter)
                    {
                        DataSet ds = new DataSet();
                        adapter.Fill(ds);
                        dataGridViewStock.DataSource = ds.Tables[0];
                    }
                }
                db.Connection.Close();
            }
            catch
            {
                MessageBox.Show("Could not load Stock info");
            }
        }

        private void Stock_Load(object sender, EventArgs e)
        {
            ShowAll();
        }

        private void BtnReturn_Click(object sender, EventArgs e)
        {
            Menu options = new Menu();
            options.Show();
            this.Hide();
        }

        private void BtnRequest_Click(object sender, EventArgs e)
        {
            try
            {
                Document doc = new Document();
                PdfWriter.GetInstance(doc, new FileStream(@"C:\Users\Drikus Grove\Desktop\Extracted GUI\cmpg223_final_project\Reports\Stock_Report.pdf", FileMode.Create));
                doc.Open();
                Paragraph p = new Paragraph("Stock Report \n Date of Report requested:" + DateTime.Now);
                doc.Add(p);
                PdfPTable table = new PdfPTable(5);
                table.WidthPercentage = 100;
                table.AddCell("stock_id");
                table.AddCell("prod_type");
                table.AddCell("product_name");
                table.AddCell("in_stock");
                table.AddCell("price_unit");

                string SQLALL = "SELECT * FROM `paris_pub`.stock";

                db.Connection.Open();
                MySqlCommand cmd = new MySqlCommand(SQLALL, db.Connection);
                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    table.AddCell(reader[0].ToString());
                    table.AddCell(reader[1].ToString());
                    table.AddCell(reader[2].ToString());
                    table.AddCell(reader[3].ToString());
                    table.AddCell(reader[4].ToString());
                }
                doc.Add(table);
                db.Connection.Close();

                doc.Close();
                MessageBox.Show("Report saved under Reports folder");
            }
            catch
            {
                MessageBox.Show("Could not create stock report");
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                int.TryParse(tbDeleteID.Text, out int ID);
                DialogResult result = MessageBox.Show("Are you sure you want to delete stock item " + ID.ToString(), "Delete Stock", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (DialogResult == DialogResult.OK)
                {
                    db.DeleteFromStock(ID);
                    MessageBox.Show("Stock removed");
                }
                ShowAll();
            }
            catch
            {
                MessageBox.Show("Could not delete stock");
            }
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT * FROM `paris_pub`.stock WHERE `stock_id` = '" + tbDeleteID.Text + "';";
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, db.Connection);
                using (db.Connection)
                {
                    using (adapter)
                    {
                        DataSet ds = new DataSet();
                        adapter.Fill(ds);
                        dataGridViewStock.DataSource = ds.Tables[0];
                    }
                }
                db.Connection.Close();
            }
            catch
            {
                MessageBox.Show("Could not find stock item");
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int.TryParse(tbStock.Text, out int iStock);
                db.InsertIntoStock(tbProdType.Text, tbProdName.Text, iStock, tbPrice.Text);
                db.Connection.Close();
                MessageBox.Show("Stock added");
                ShowAll();
            }
            catch
            {
                MessageBox.Show("Could not add stock");
            }
        }

        private void BtnUpdate_Click_1(object sender, EventArgs e)
        {
            try
            {
                int.TryParse(tbAddID.Text, out int ID);
                decimal.TryParse(tbPrice.Text, out decimal dPrice);
                db.ChangeStock(ID, tbProdType.Text, tbProdName.Text, tbStock.Text, dPrice);
                db.Connection.Close();
                MessageBox.Show("Stock updated");
                ShowAll();
            }
            catch
            {
                MessageBox.Show("Could not update stock");
            }
        }

        private void BtnShowAll_Click(object sender, EventArgs e)
        {
            ShowAll();
        }
    }
}
