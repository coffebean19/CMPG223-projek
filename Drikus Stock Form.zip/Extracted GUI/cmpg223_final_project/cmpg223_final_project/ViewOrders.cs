﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace cmpg223_final_project
{
    public partial class ViewOrders : Form
    {
        public ViewOrders()
        {
            InitializeComponent();
        }

        DbConnection db = new DbConnection();

        private void BtnReturn_Click(object sender, EventArgs e)
        {
            Menu options = new Menu();
            options.Show();
            this.Hide();
        }

        private void ViewOrders_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM `paris_pub`.order";
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, db.Connection);
            using (db.Connection)
            {
                using (adapter)
                {
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    dataGridViewOrders.DataSource = ds.Tables[0];
                }
            }
            db.Connection.Close();
        }

        private void BtnRequest_Click(object sender, EventArgs e)
        {
            Document doc = new Document();
            PdfWriter.GetInstance(doc, new FileStream(@"C:\Users\Drikus Grove\Desktop\Extracted GUI\cmpg223_final_project\Reports\Orders_Report.pdf", FileMode.Create));
            doc.Open();
            Paragraph p = new Paragraph("Orders Report \n Date of Report requested:" + DateTime.Now);
            doc.Add(p);
            PdfPTable table = new PdfPTable(7);
            table.WidthPercentage = 100;
            table.AddCell("order_id");
            table.AddCell("supplier");
            table.AddCell("amount");
            table.AddCell("order_date");
            table.AddCell("arrival_date");
            table.AddCell("stock_id");
            table.AddCell("cost");

            string SQLALL = "SELECT * FROM `paris_pub`.order";

            db.Connection.Open();
            MySqlCommand cmd = new MySqlCommand(SQLALL, db.Connection);
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                table.AddCell(reader[0].ToString());
                table.AddCell(reader[1].ToString());
                table.AddCell(reader[2].ToString());
                table.AddCell(reader[3].ToString());
                table.AddCell(reader[4].ToString());
                table.AddCell(reader[5].ToString());
                table.AddCell(reader[6].ToString());
            }
            doc.Add(table);
            db.Connection.Close();

            doc.Close();
        }
    }
}
