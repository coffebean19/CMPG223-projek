﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web;
using System.IO;
using MySql.Data.MySqlClient;

namespace cmpg223_final_project
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void SalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewSales allSales = new ViewSales();
            allSales.Show();
            this.Hide();
        }

        private void SalesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ViewStock vStock = new ViewStock();
            vStock.Show();
            this.Hide();
        }

        private void Btn_Login_Click(object sender, EventArgs e)
        {
            Login form1 = new Login();
            form1.Show();
            this.Hide();
        }

        private void Menu_Load(object sender, EventArgs e)
        {
        
        }

        private void ViewOrdersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewOrders vOrders = new ViewOrders();
            vOrders.Show();
            this.Hide();
        }
    }
}
