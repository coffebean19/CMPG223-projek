﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cmpg223_final_project
{
    public partial class sales : Form
    {
        public sales()
        {
            this.TopMost = true;
            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            InitializeComponent();
        }

        private void sales_Load(object sender, EventArgs e)
        {
            //txbCash.Text = verify.sfloat.ToString();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login form1 = new Login();
            form1.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        
        private void btnPay_Click(object sender, EventArgs e)
        { 
            int Ttotal, Ptotal, Tip;
            Ptotal = Convert.ToInt32(txbPayCash.Text) - Convert.ToInt32(txbTotal.Text);
            txbChange.Text = Ptotal.ToString();
            Ttotal = Convert.ToInt32(txbCash.Text);
            if (Ptotal >= 0)
            {
                Ttotal += Convert.ToInt32(txbTotal.Text);
                txbCash.Text = Ttotal.ToString();
                txbPayCash.Text = "";
                txbTotal.Text = "";
            }
            else if (Ptotal < 0)
            {
                MessageBox.Show("The amount payed is not enough!!");
                txbPayCash.Text = "";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txbPayCash_KeyPress(object sender, KeyPressEventArgs e)
        {
            txbChange.Text = "";
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }

        }
    }
}
