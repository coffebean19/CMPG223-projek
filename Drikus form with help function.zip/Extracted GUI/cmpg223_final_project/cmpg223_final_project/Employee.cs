﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cmpg223_final_project
{
    public partial class Employee : Form
    {
        public Employee()
        {
            this.TopMost = true;
            //this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None; 
            InitializeComponent();
        }

        private void Btn_Login_Click(object sender, EventArgs e)
        {
            if (txb_Username.Text == "User" && txb_Pwd.Text == "Pwd")
            {
                txb_Pwd.Text = "";
                txb_Username.Text = "";
                sales sales = new sales();
                sales.Show();
                //Menu options = new Menu();
                //options.Show();
                this.Hide();
            }
            else
            {
                lblMessage.Text = "Incorrect login details!";
                lblMessage.Visible = true;
            }
        }

        private void Label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Login form1 = new Login();
            form1.Show();
            this.Hide();
        }
    }
}
