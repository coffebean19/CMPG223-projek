﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace cmpg223_final_project
{
    public partial class ViewStock : Form
    {
        public ViewStock()
        {
            InitializeComponent();
        }

        DbConnection db = new DbConnection();

        private void ViewStock_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM `paris_pub`.stock";
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, db.Connection);
            using (db.Connection)
            {
                using (adapter)
                {
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    dataGridViewStock.DataSource = ds.Tables[0];
                }
            }
            db.Connection.Close();
        }

        private void BtnReturn_Click(object sender, EventArgs e)
        {
            Menu options = new Menu();
            options.Show();
            this.Hide();
        }

        private void BtnRequest_Click(object sender, EventArgs e)
        {
            Document doc = new Document();
            PdfWriter.GetInstance(doc, new FileStream(@"C:\Users\Drikus Grove\Desktop\Extracted GUI\cmpg223_final_project\Reports\Stock_Report.pdf", FileMode.Create));
            doc.Open();
            Paragraph p = new Paragraph("Stock Report \n Date of Report requested:" + DateTime.Now);
            doc.Add(p);
            PdfPTable table = new PdfPTable(5);
            table.WidthPercentage = 100;
            table.AddCell("stock_id");
            table.AddCell("prod_type");
            table.AddCell("product_name");
            table.AddCell("in_stock");
            table.AddCell("price_unit");

            string SQLALL = "SELECT * FROM `paris_pub`.stock";

            db.Connection.Open();
            MySqlCommand cmd = new MySqlCommand(SQLALL, db.Connection);
            var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                table.AddCell(reader[0].ToString());
                table.AddCell(reader[1].ToString());
                table.AddCell(reader[2].ToString());
                table.AddCell(reader[3].ToString());
                table.AddCell(reader[4].ToString());
            }
            doc.Add(table);
            db.Connection.Close();

            doc.Close();
        }
    }
}
